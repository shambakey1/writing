var s_pageName = '';
var s_server = '';
var s_channel = '';
var s_prop1 =  '';
var s_prop11 = '';
var s_prop12  = '';
var s_account = '';
var s_pageType  = '';
var s_hier1 = '';
var s_purchaseID = '';
var s_products = '';
var s_events = '';
var s_currencyCode = '';
var s_prop30 = '';
var s_eVar30 = '';
//if _2eco
var s_eVar41 = '';
var s_eVar42 = '';
//from /daily/common/siteanalytics.js not already in pagelogging_header.htx
var s_prop34;
/* E-commerce Variables */
var s_campaign;
var s_state;
var s_zip;
var s_eVar1;
var s_eVar2;
var s_eVar3;
var s_eVar4;
var s_eVar5;
var s_eVar31;
var s_eVar32;
var s_eVar33;
var s_eVar34;